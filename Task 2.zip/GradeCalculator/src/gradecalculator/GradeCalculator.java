/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gradecalculator;

import java.util.Scanner;

/**
 *
 * @author hacker2
 */
public class GradeCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter num of subjects: ");
        int numOfSubjects = sc.nextInt();
        int[] mark = new int[numOfSubjects];
        int index = 1;
        int markSum = 0;
        for(int i=0;i<numOfSubjects;i++){
            System.out.print("Subject "+index+": ");
            mark[i] = sc.nextInt();
            markSum+=mark[i];
            index++;
        }
        double average = 0;
        average = markSum/numOfSubjects;
        
        String grade="";
        
        if(average >= 50 && average <=100){
             
             if(average <75){
                 grade="Pass";
             }else if(average > 74){
                 grade="Pass With Distintion";
             }
        }else{
            grade="Fail";
        }
        
        
        String output="\nResults"
                + "\n\nTotal Marks: "+markSum+""
                + "\nAverage Percentage: "+average+""
                + "\nGrade: "+grade;
        
        System.out.println(output);
        
    }
    
}
