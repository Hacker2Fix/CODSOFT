import java.util.Scanner;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        balance = initialBalance;
    }

    public boolean deposit(double amnt) {
        if (amnt > 0) {
            balance += amnt;
            return true;
        } else {
            System.out.println("enter valid amount");
            return false;
        }
    }

    public boolean withdraw(double amnt) {
        if (amnt > 0 && balance >= amnt) {
            balance -= amnt;
            return true;
        } else {
            System.out.println("insufficient amount for withdrawal.");
            return false;
        }
    }

    public double checkBalance() {
        return balance;
    }
}


public class ATM {
    private BankAccount bankAccount;
    private Scanner scanner;

    public ATM(BankAccount bankAccount) {
        this.bankAccount = bankAccount;
        scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        System.out.println("\nATM Menu:\n");
        System.out.println("1. Withdraw");
        System.out.println("2. Deposit");
        System.out.println("3. Check Balance");
        System.out.println("4. Exit");
    }

    public void start() {
        while (true) {
            displayMenu();
            System.out.print("Enter your choice (1-4): ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmnt = scanner.nextDouble();
                    if (bankAccount.withdraw(withdrawAmnt)) {
                        System.out.println("Withdrawal successful.");
                    }
                    break;
                case 2:
                    System.out.print("Enter amount to deposit: ");
                    double depositAmnt = scanner.nextDouble();
                    if (bankAccount.deposit(depositAmnt)) {
                        System.out.println("Deposit successful.");
                    }
                    break;
                case 3:
                    System.out.println("Your balance: " + bankAccount.checkBalance());
                    break;
                case 4:
                    System.out.println("Thank you for using the ATM.");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter initial balance: ");
        double initialAmnt = sc.nextDouble();
        BankAccount bankA = new BankAccount(initialAmnt);
        
        ATM machine = new ATM(bankA);
        machine.start();
        
        sc.close();
    }
}
