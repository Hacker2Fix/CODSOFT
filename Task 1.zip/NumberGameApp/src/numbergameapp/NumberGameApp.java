/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numbergameapp;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hacker2
 */
public class NumberGameApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int random = generateRandom();
        
        int option = menu();
        
        int count =0,cnt = 0;
        
        if(option == 1){
                System.out.print("Enter number: ");
                int user_number = sc.nextInt();

                String feedBck = check(user_number,random);
                System.out.println(feedBck);
                
                if(!feedBck.equals("correct")){
                    cnt++;
                }
                
                count++;
        }else if(option == 2){
            
                System.out.print("Enter number: ");
                int user_number = sc.nextInt();

                String feedBck = check(user_number,random);
                
                
                if(!feedBck.equals("correct")){
                    cnt++;
                }
                System.out.println(feedBck);

                count++;
                while (!feedBck.equals("correct")) {  
                    
                     System.out.print("Enter number: ");
                     user_number = sc.nextInt();

                     feedBck = check(user_number,random);
                     
                           if(!feedBck.equals("correct")){
                                cnt++;
                            }

                     System.out.println(feedBck);
                     count++;
                     
                }           
        }
        
        summary(count,cnt);
        
        
    }

    private static int generateRandom() {
        Random random = new Random();
        int ran_num = random.nextInt(100) + 1;
        return ran_num;
    }

    private static String check(int user_number, int random) {
        String feedback = "";
        if(user_number == random){
            feedback = "correct";
        }else if(user_number > random){
            feedback = "too high,";
        }else if(user_number < random){
            feedback = " too low";
        }
        return feedback;
    }

    private static int menu() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 1 for single attemps.\n"
                + "Enter 2 for multiple attempts.\nOption: ");
        int option = sc.nextInt();
        return option;
    }

    private static void summary(int count, int cnt) {
        System.out.println("Attempts: "+count+"\nloses : "+cnt);
    }
    
}
